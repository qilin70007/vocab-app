﻿# 鍚姩.ps1
$script:ErrorActionPreference = "Stop"
$host.UI.RawUI.WindowTitle = "Vocab App"

Write-Host "============================" -ForegroundColor Cyan
Write-Host "  Vocab App Starting..." -ForegroundColor Cyan
Write-Host "============================" -ForegroundColor Cyan

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir
Write-Host "Dir: $(Get-Location)" -ForegroundColor Gray

# Check node
$nodePath = (Get-Command "node.exe" -ErrorAction SilentlyContinue).Source
if (-not $nodePath) {
    Write-Host "[ERR] Node.js not found" -ForegroundColor Red
    Read-Host "Press Enter"
    exit 1
}
Write-Host "Node: $nodePath" -ForegroundColor Gray

# Check files
$missing = @()
if (-not (Test-Path "server.js")) { $missing += "server.js" }
if (-not (Test-Path "words.json")) { $missing += "words.json" }
if ($missing.Count -gt 0) {
    Write-Host "[ERR] Missing: $($missing -join ', ')" -ForegroundColor Red
    Read-Host "Press Enter"
    exit 1
}
Write-Host "Files: OK" -ForegroundColor Gray

# Install deps
if (-not (Test-Path "node_modules")) {
    Write-Host "Installing..." -ForegroundColor Yellow
    npm install 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERR] npm install failed" -ForegroundColor Red
        Read-Host "Press Enter"
        exit 1
    }
}

# Kill old process on port 3000
try {
    $connections = netstat -ano | Select-String ":3000.*LISTENING"
    foreach ($c in $connections) {
        $parts = $c -split '\s+'
        $pid = $parts[-1]
        if ($pid -match '^\d+$') {
            Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
            Start-Sleep -Milliseconds 300
        }
    }
} catch {}

Write-Host ""
Write-Host "Starting server..." -ForegroundColor Green
Write-Host "http://localhost:3000" -ForegroundColor Cyan
Write-Host ""

# Start server
node server.js

Read-Host "Press Enter"
