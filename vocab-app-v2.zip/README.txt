﻿# 背单词 App 使用说明

## 快速启动
1. 双击 启动.bat
2. 打开浏览器访问 http://localhost:3000

## 首次运行
如果提示"npm install 失败"，请手动运行：
`
npm install
`

## 文件说明
- server.js - 服务器主程序
- data/words_800.json - 词库数据（794个词汇）
- public/ - 前端页面
- data/progress.json - 学习进度记录

## 数据更新
词库已用2026年新OCR数据更新， meanings 更精确。
